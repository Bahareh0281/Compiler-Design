public class A {
    B b;
}
public class B extends C {
    A a;
}
public class C {
    int a=5;
}