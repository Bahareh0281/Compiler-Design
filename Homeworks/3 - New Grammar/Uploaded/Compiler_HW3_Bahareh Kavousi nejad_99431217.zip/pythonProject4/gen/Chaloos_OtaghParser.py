# Generated from D:/Bahareh/7/Files/Compiler/pythonProject4/Chaloos_Otagh.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,25,122,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,1,0,4,0,34,8,0,11,0,12,0,35,1,1,1,1,1,1,1,1,
        1,1,3,1,43,8,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,55,8,
        2,1,3,1,3,1,3,1,4,1,4,1,5,1,5,5,5,64,8,5,10,5,12,5,67,9,5,1,6,1,
        6,1,6,3,6,72,8,6,1,7,1,7,1,7,5,7,77,8,7,10,7,12,7,80,9,7,1,8,1,8,
        1,8,1,8,1,9,1,9,1,9,1,9,1,9,1,9,3,9,92,8,9,1,10,1,10,1,11,1,11,1,
        12,1,12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,1,13,1,14,1,
        14,4,14,112,8,14,11,14,12,14,113,1,14,1,14,1,15,1,15,1,15,1,15,1,
        15,0,0,16,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,0,4,1,0,17,
        18,2,0,1,1,22,23,1,0,8,10,1,0,19,20,118,0,33,1,0,0,0,2,42,1,0,0,
        0,4,54,1,0,0,0,6,56,1,0,0,0,8,59,1,0,0,0,10,61,1,0,0,0,12,71,1,0,
        0,0,14,73,1,0,0,0,16,81,1,0,0,0,18,91,1,0,0,0,20,93,1,0,0,0,22,95,
        1,0,0,0,24,97,1,0,0,0,26,103,1,0,0,0,28,109,1,0,0,0,30,117,1,0,0,
        0,32,34,3,2,1,0,33,32,1,0,0,0,34,35,1,0,0,0,35,33,1,0,0,0,35,36,
        1,0,0,0,36,1,1,0,0,0,37,43,3,6,3,0,38,43,3,4,2,0,39,43,3,24,12,0,
        40,43,3,26,13,0,41,43,3,28,14,0,42,37,1,0,0,0,42,38,1,0,0,0,42,39,
        1,0,0,0,42,40,1,0,0,0,42,41,1,0,0,0,43,3,1,0,0,0,44,45,3,6,3,0,45,
        46,5,16,0,0,46,47,3,12,6,0,47,48,5,15,0,0,48,55,1,0,0,0,49,50,3,
        10,5,0,50,51,5,16,0,0,51,52,3,12,6,0,52,53,5,15,0,0,53,55,1,0,0,
        0,54,44,1,0,0,0,54,49,1,0,0,0,55,5,1,0,0,0,56,57,3,8,4,0,57,58,3,
        10,5,0,58,7,1,0,0,0,59,60,7,0,0,0,60,9,1,0,0,0,61,65,7,1,0,0,62,
        64,7,1,0,0,63,62,1,0,0,0,64,67,1,0,0,0,65,63,1,0,0,0,65,66,1,0,0,
        0,66,11,1,0,0,0,67,65,1,0,0,0,68,72,3,14,7,0,69,72,3,16,8,0,70,72,
        3,22,11,0,71,68,1,0,0,0,71,69,1,0,0,0,71,70,1,0,0,0,72,13,1,0,0,
        0,73,78,3,18,9,0,74,75,5,4,0,0,75,77,3,18,9,0,76,74,1,0,0,0,77,80,
        1,0,0,0,78,76,1,0,0,0,78,79,1,0,0,0,79,15,1,0,0,0,80,78,1,0,0,0,
        81,82,3,18,9,0,82,83,3,20,10,0,83,84,3,18,9,0,84,17,1,0,0,0,85,86,
        5,11,0,0,86,87,3,12,6,0,87,88,5,12,0,0,88,92,1,0,0,0,89,92,3,10,
        5,0,90,92,5,21,0,0,91,85,1,0,0,0,91,89,1,0,0,0,91,90,1,0,0,0,92,
        19,1,0,0,0,93,94,7,2,0,0,94,21,1,0,0,0,95,96,7,3,0,0,96,23,1,0,0,
        0,97,98,5,2,0,0,98,99,5,11,0,0,99,100,3,30,15,0,100,101,5,12,0,0,
        101,102,3,28,14,0,102,25,1,0,0,0,103,104,5,3,0,0,104,105,5,11,0,
        0,105,106,3,30,15,0,106,107,5,12,0,0,107,108,3,28,14,0,108,27,1,
        0,0,0,109,111,5,13,0,0,110,112,3,2,1,0,111,110,1,0,0,0,112,113,1,
        0,0,0,113,111,1,0,0,0,113,114,1,0,0,0,114,115,1,0,0,0,115,116,5,
        14,0,0,116,29,1,0,0,0,117,118,5,11,0,0,118,119,3,12,6,0,119,120,
        5,12,0,0,120,31,1,0,0,0,8,35,42,54,65,71,78,91,113
    ]

class Chaloos_OtaghParser ( Parser ):

    grammarFileName = "Chaloos_Otagh.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'_'", "'if'", "'while'", "'+'", "'-'", 
                     "'*'", "'/'", "'=='", "'>'", "'<'", "'('", "')'", "'{'", 
                     "'}'", "';'", "'='", "'boolean'", "'int'", "'true'", 
                     "'false'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "ADD", "SUB", "MUL", "DIV", "EQ", "GT", "LT", "LPAREN", 
                      "RPAREN", "LBRACE", "RBRACE", "SEMI", "ASSIGN", "BOOL", 
                      "INT_TYPE", "TRUE", "FALSE", "INT", "Letter", "Digit", 
                      "WS", "COMMENT" ]

    RULE_program = 0
    RULE_statement = 1
    RULE_assignment = 2
    RULE_variableDeclaration = 3
    RULE_variableType = 4
    RULE_variableName = 5
    RULE_expression = 6
    RULE_additionExpression = 7
    RULE_comparisonExpression = 8
    RULE_primaryExpression = 9
    RULE_comparisonOperator = 10
    RULE_booleanValue = 11
    RULE_ifStatement = 12
    RULE_whileStatement = 13
    RULE_compoundStatement = 14
    RULE_booleanCondition = 15

    ruleNames =  [ "program", "statement", "assignment", "variableDeclaration", 
                   "variableType", "variableName", "expression", "additionExpression", 
                   "comparisonExpression", "primaryExpression", "comparisonOperator", 
                   "booleanValue", "ifStatement", "whileStatement", "compoundStatement", 
                   "booleanCondition" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    ADD=4
    SUB=5
    MUL=6
    DIV=7
    EQ=8
    GT=9
    LT=10
    LPAREN=11
    RPAREN=12
    LBRACE=13
    RBRACE=14
    SEMI=15
    ASSIGN=16
    BOOL=17
    INT_TYPE=18
    TRUE=19
    FALSE=20
    INT=21
    Letter=22
    Digit=23
    WS=24
    COMMENT=25

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Chaloos_OtaghParser.StatementContext)
            else:
                return self.getTypedRuleContext(Chaloos_OtaghParser.StatementContext,i)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = Chaloos_OtaghParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 32
                self.statement()
                self.state = 35 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 12984334) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variableDeclaration(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.VariableDeclarationContext,0)


        def assignment(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.AssignmentContext,0)


        def ifStatement(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.IfStatementContext,0)


        def whileStatement(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.WhileStatementContext,0)


        def compoundStatement(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.CompoundStatementContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_statement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStatement" ):
                listener.enterStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStatement" ):
                listener.exitStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStatement" ):
                return visitor.visitStatement(self)
            else:
                return visitor.visitChildren(self)




    def statement(self):

        localctx = Chaloos_OtaghParser.StatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_statement)
        try:
            self.state = 42
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 37
                self.variableDeclaration()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 38
                self.assignment()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 39
                self.ifStatement()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 40
                self.whileStatement()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 41
                self.compoundStatement()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variableDeclaration(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.VariableDeclarationContext,0)


        def ASSIGN(self):
            return self.getToken(Chaloos_OtaghParser.ASSIGN, 0)

        def expression(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.ExpressionContext,0)


        def SEMI(self):
            return self.getToken(Chaloos_OtaghParser.SEMI, 0)

        def variableName(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.VariableNameContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_assignment

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssignment" ):
                listener.enterAssignment(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssignment" ):
                listener.exitAssignment(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignment" ):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)




    def assignment(self):

        localctx = Chaloos_OtaghParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_assignment)
        try:
            self.state = 54
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [17, 18]:
                self.enterOuterAlt(localctx, 1)
                self.state = 44
                self.variableDeclaration()
                self.state = 45
                self.match(Chaloos_OtaghParser.ASSIGN)
                self.state = 46
                self.expression()
                self.state = 47
                self.match(Chaloos_OtaghParser.SEMI)
                pass
            elif token in [1, 22, 23]:
                self.enterOuterAlt(localctx, 2)
                self.state = 49
                self.variableName()
                self.state = 50
                self.match(Chaloos_OtaghParser.ASSIGN)
                self.state = 51
                self.expression()
                self.state = 52
                self.match(Chaloos_OtaghParser.SEMI)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableDeclarationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def variableType(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.VariableTypeContext,0)


        def variableName(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.VariableNameContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_variableDeclaration

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariableDeclaration" ):
                listener.enterVariableDeclaration(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariableDeclaration" ):
                listener.exitVariableDeclaration(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariableDeclaration" ):
                return visitor.visitVariableDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def variableDeclaration(self):

        localctx = Chaloos_OtaghParser.VariableDeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_variableDeclaration)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 56
            self.variableType()
            self.state = 57
            self.variableName()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableTypeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT_TYPE(self):
            return self.getToken(Chaloos_OtaghParser.INT_TYPE, 0)

        def BOOL(self):
            return self.getToken(Chaloos_OtaghParser.BOOL, 0)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_variableType

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariableType" ):
                listener.enterVariableType(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariableType" ):
                listener.exitVariableType(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariableType" ):
                return visitor.visitVariableType(self)
            else:
                return visitor.visitChildren(self)




    def variableType(self):

        localctx = Chaloos_OtaghParser.VariableTypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_variableType)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 59
            _la = self._input.LA(1)
            if not(_la==17 or _la==18):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VariableNameContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Letter(self, i:int=None):
            if i is None:
                return self.getTokens(Chaloos_OtaghParser.Letter)
            else:
                return self.getToken(Chaloos_OtaghParser.Letter, i)

        def Digit(self, i:int=None):
            if i is None:
                return self.getTokens(Chaloos_OtaghParser.Digit)
            else:
                return self.getToken(Chaloos_OtaghParser.Digit, i)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_variableName

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterVariableName" ):
                listener.enterVariableName(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitVariableName" ):
                listener.exitVariableName(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVariableName" ):
                return visitor.visitVariableName(self)
            else:
                return visitor.visitChildren(self)




    def variableName(self):

        localctx = Chaloos_OtaghParser.VariableNameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_variableName)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 12582914) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 65
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,3,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 62
                    _la = self._input.LA(1)
                    if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 12582914) != 0)):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume() 
                self.state = 67
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additionExpression(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.AdditionExpressionContext,0)


        def comparisonExpression(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.ComparisonExpressionContext,0)


        def booleanValue(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.BooleanValueContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_expression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpression" ):
                listener.enterExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpression" ):
                listener.exitExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)




    def expression(self):

        localctx = Chaloos_OtaghParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_expression)
        try:
            self.state = 71
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 68
                self.additionExpression()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 69
                self.comparisonExpression()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 70
                self.booleanValue()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditionExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primaryExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Chaloos_OtaghParser.PrimaryExpressionContext)
            else:
                return self.getTypedRuleContext(Chaloos_OtaghParser.PrimaryExpressionContext,i)


        def ADD(self, i:int=None):
            if i is None:
                return self.getTokens(Chaloos_OtaghParser.ADD)
            else:
                return self.getToken(Chaloos_OtaghParser.ADD, i)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_additionExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAdditionExpression" ):
                listener.enterAdditionExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAdditionExpression" ):
                listener.exitAdditionExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditionExpression" ):
                return visitor.visitAdditionExpression(self)
            else:
                return visitor.visitChildren(self)




    def additionExpression(self):

        localctx = Chaloos_OtaghParser.AdditionExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_additionExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 73
            self.primaryExpression()
            self.state = 78
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==4:
                self.state = 74
                self.match(Chaloos_OtaghParser.ADD)
                self.state = 75
                self.primaryExpression()
                self.state = 80
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def primaryExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Chaloos_OtaghParser.PrimaryExpressionContext)
            else:
                return self.getTypedRuleContext(Chaloos_OtaghParser.PrimaryExpressionContext,i)


        def comparisonOperator(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.ComparisonOperatorContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_comparisonExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonExpression" ):
                listener.enterComparisonExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonExpression" ):
                listener.exitComparisonExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparisonExpression" ):
                return visitor.visitComparisonExpression(self)
            else:
                return visitor.visitChildren(self)




    def comparisonExpression(self):

        localctx = Chaloos_OtaghParser.ComparisonExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_comparisonExpression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self.primaryExpression()
            self.state = 82
            self.comparisonOperator()
            self.state = 83
            self.primaryExpression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Chaloos_OtaghParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(Chaloos_OtaghParser.RPAREN, 0)

        def variableName(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.VariableNameContext,0)


        def INT(self):
            return self.getToken(Chaloos_OtaghParser.INT, 0)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_primaryExpression

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPrimaryExpression" ):
                listener.enterPrimaryExpression(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPrimaryExpression" ):
                listener.exitPrimaryExpression(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimaryExpression" ):
                return visitor.visitPrimaryExpression(self)
            else:
                return visitor.visitChildren(self)




    def primaryExpression(self):

        localctx = Chaloos_OtaghParser.PrimaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_primaryExpression)
        try:
            self.state = 91
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [11]:
                self.enterOuterAlt(localctx, 1)
                self.state = 85
                self.match(Chaloos_OtaghParser.LPAREN)
                self.state = 86
                self.expression()
                self.state = 87
                self.match(Chaloos_OtaghParser.RPAREN)
                pass
            elif token in [1, 22, 23]:
                self.enterOuterAlt(localctx, 2)
                self.state = 89
                self.variableName()
                pass
            elif token in [21]:
                self.enterOuterAlt(localctx, 3)
                self.state = 90
                self.match(Chaloos_OtaghParser.INT)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonOperatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GT(self):
            return self.getToken(Chaloos_OtaghParser.GT, 0)

        def EQ(self):
            return self.getToken(Chaloos_OtaghParser.EQ, 0)

        def LT(self):
            return self.getToken(Chaloos_OtaghParser.LT, 0)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_comparisonOperator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparisonOperator" ):
                listener.enterComparisonOperator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparisonOperator" ):
                listener.exitComparisonOperator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComparisonOperator" ):
                return visitor.visitComparisonOperator(self)
            else:
                return visitor.visitChildren(self)




    def comparisonOperator(self):

        localctx = Chaloos_OtaghParser.ComparisonOperatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_comparisonOperator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1792) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BooleanValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TRUE(self):
            return self.getToken(Chaloos_OtaghParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(Chaloos_OtaghParser.FALSE, 0)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_booleanValue

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBooleanValue" ):
                listener.enterBooleanValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBooleanValue" ):
                listener.exitBooleanValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBooleanValue" ):
                return visitor.visitBooleanValue(self)
            else:
                return visitor.visitChildren(self)




    def booleanValue(self):

        localctx = Chaloos_OtaghParser.BooleanValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_booleanValue)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            _la = self._input.LA(1)
            if not(_la==19 or _la==20):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IfStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Chaloos_OtaghParser.LPAREN, 0)

        def booleanCondition(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.BooleanConditionContext,0)


        def RPAREN(self):
            return self.getToken(Chaloos_OtaghParser.RPAREN, 0)

        def compoundStatement(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.CompoundStatementContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_ifStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIfStatement" ):
                listener.enterIfStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIfStatement" ):
                listener.exitIfStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIfStatement" ):
                return visitor.visitIfStatement(self)
            else:
                return visitor.visitChildren(self)




    def ifStatement(self):

        localctx = Chaloos_OtaghParser.IfStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_ifStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            self.match(Chaloos_OtaghParser.T__1)
            self.state = 98
            self.match(Chaloos_OtaghParser.LPAREN)
            self.state = 99
            self.booleanCondition()
            self.state = 100
            self.match(Chaloos_OtaghParser.RPAREN)
            self.state = 101
            self.compoundStatement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class WhileStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Chaloos_OtaghParser.LPAREN, 0)

        def booleanCondition(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.BooleanConditionContext,0)


        def RPAREN(self):
            return self.getToken(Chaloos_OtaghParser.RPAREN, 0)

        def compoundStatement(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.CompoundStatementContext,0)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_whileStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhileStatement" ):
                listener.enterWhileStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhileStatement" ):
                listener.exitWhileStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitWhileStatement" ):
                return visitor.visitWhileStatement(self)
            else:
                return visitor.visitChildren(self)




    def whileStatement(self):

        localctx = Chaloos_OtaghParser.WhileStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_whileStatement)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.match(Chaloos_OtaghParser.T__2)
            self.state = 104
            self.match(Chaloos_OtaghParser.LPAREN)
            self.state = 105
            self.booleanCondition()
            self.state = 106
            self.match(Chaloos_OtaghParser.RPAREN)
            self.state = 107
            self.compoundStatement()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CompoundStatementContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LBRACE(self):
            return self.getToken(Chaloos_OtaghParser.LBRACE, 0)

        def RBRACE(self):
            return self.getToken(Chaloos_OtaghParser.RBRACE, 0)

        def statement(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(Chaloos_OtaghParser.StatementContext)
            else:
                return self.getTypedRuleContext(Chaloos_OtaghParser.StatementContext,i)


        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_compoundStatement

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCompoundStatement" ):
                listener.enterCompoundStatement(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCompoundStatement" ):
                listener.exitCompoundStatement(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCompoundStatement" ):
                return visitor.visitCompoundStatement(self)
            else:
                return visitor.visitChildren(self)




    def compoundStatement(self):

        localctx = Chaloos_OtaghParser.CompoundStatementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_compoundStatement)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 109
            self.match(Chaloos_OtaghParser.LBRACE)
            self.state = 111 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 110
                self.statement()
                self.state = 113 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 12984334) != 0)):
                    break

            self.state = 115
            self.match(Chaloos_OtaghParser.RBRACE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BooleanConditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LPAREN(self):
            return self.getToken(Chaloos_OtaghParser.LPAREN, 0)

        def expression(self):
            return self.getTypedRuleContext(Chaloos_OtaghParser.ExpressionContext,0)


        def RPAREN(self):
            return self.getToken(Chaloos_OtaghParser.RPAREN, 0)

        def getRuleIndex(self):
            return Chaloos_OtaghParser.RULE_booleanCondition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBooleanCondition" ):
                listener.enterBooleanCondition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBooleanCondition" ):
                listener.exitBooleanCondition(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBooleanCondition" ):
                return visitor.visitBooleanCondition(self)
            else:
                return visitor.visitChildren(self)




    def booleanCondition(self):

        localctx = Chaloos_OtaghParser.BooleanConditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_booleanCondition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(Chaloos_OtaghParser.LPAREN)
            self.state = 118
            self.expression()
            self.state = 119
            self.match(Chaloos_OtaghParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





