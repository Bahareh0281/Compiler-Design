from antlr4 import *
from grammars.JavaLexer import JavaLexer
import os

def convert_multiline_comments(input_address):
    file_stream = FileStream(input_address)
    lexer = JavaLexer(file_stream)
    token = lexer.nextToken()
    refactoredSTR = ''

    while token.type != Token.EOF:
        token_text = token.text
        if token.type == JavaLexer.COMMENT and token_text.startswith("/*") and token_text.endswith("*/"):       # Check if it's a multiline comment
            lines = token_text[2:-2].strip().split('\n')                                                        # Split the comment into lines
            refactoredSTR += '\n'.join(['// ' + line.strip() for line in lines]) + '\n'                         # Add single line comments for each line
        else:
            refactoredSTR += token_text

        token = lexer.nextToken()

    return refactoredSTR

input_address = 'input.java'
refactored_code = convert_multiline_comments(input_address)
print(refactored_code)