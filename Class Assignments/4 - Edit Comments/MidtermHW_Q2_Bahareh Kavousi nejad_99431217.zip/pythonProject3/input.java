/*Hello
I am Bahareh
*/
console.log("Bahareh")
// Hello
// Bye
/*Hello
I am Bahareh
*/